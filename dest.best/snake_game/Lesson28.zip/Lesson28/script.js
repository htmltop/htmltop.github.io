let cell_w = 30;

class Snake_Game{
	constructor(){
		// створюємо масив даних поля:
		this.field = [];
		for (let i = 0; i < 17; i++) {
			let temp_arr = []
			for (let j = 0; j < 17; j++) {
				temp_arr.push(0);
			}
			this.field.push(temp_arr);
		}
		// створюємо властивості для змійки:
		this.snake_direction = "r"
		this.snake_position = [[8, 8], [7, 8], [6, 8]]
		// this.snake_x = 8
		// this.snake_y = 8
		// створюємо інструменти для малювання:
		let canvas = document.getElementById("canvas");
		this.pen = canvas.getContext("2d");
		this.pen.fillStyle = "#8D8";
		this.pen.fillRect(0, 0, 510, 510);
		// просто перевірка:
		// alert("Об'єкт гри створено")
		this.Print_field()

	}
	Print_field(){
		for (let i = 0; i < this.field.length; i++) {
			for (let j = 0; j < this.field[i].length; j++) {
				this.pen.fillStyle = "#8D8";
				this.pen.strokeStyle = "#000";
				this.pen.fillRect(  j * cell_w, i * cell_w, cell_w, cell_w);
				this.pen.strokeRect(j * cell_w, i * cell_w, cell_w, cell_w);
			}
		}
		this.pen.fillStyle = "#FA4";
		for (var i = 0; i < this.snake_position.length; i++) {
			this.pen.fillRect(
				this.snake_position[i][0] * cell_w,	
				this.snake_position[i][1] * cell_w,	
				cell_w, cell_w			
				);
			this.pen.strokeRect(
				this.snake_position[i][0] * cell_w,	
				this.snake_position[i][1] * cell_w,	
				cell_w, cell_w
				);
			this.pen.fillStyle = "#D82";
		}
	}
	Step(){
		let x = this.snake_position[0][0]
		let y =	this.snake_position[0][1]
		if      (this.snake_direction = "r") {x += 1}
		else if (this.snake_direction = "l") {x -= 1}
		else if (this.snake_direction = "t") {y += 1}
		else if (this.snake_direction = "b") {y -= 1}
		this.snake_position.unshift([x, y])
		this.snake_position.pop()
		this.Print_field()
	}
}

let game_1;

$(document).ready(function(){
	game_1 = new Snake_Game();
})

function Start(){
	setInterval(function() {
		game_1.Step();
	}, 1000)
}